"""
Cinematic dual-theme system — Remote Desktop Manager

Two complete themes (DARK / LIGHT) with vibrant, cinema-grade palette.
Gradient accents, premium typography, Nike/Apple-level polish.
"""

from dataclasses import dataclass


@dataclass
class Theme:
    name: str
    # Backgrounds
    bg_root: str
    bg_sidebar: str
    bg_card: str
    bg_surface: str
    bg_hover: str
    bg_input: str
    bg_overlay: str
    # Borders
    border: str
    border_focus: str
    # Text
    text_primary: str
    text_secondary: str
    text_muted: str
    text_dim: str
    # Accents
    accent: str
    accent_hover: str
    accent_gradient_start: str
    accent_gradient_end: str
    success: str
    success_bg: str
    warning: str
    warning_bg: str
    danger: str
    danger_bg: str
    info: str
    info_bg: str
    # Scrollbar
    scrollbar_bg: str
    scrollbar_handle: str
    scrollbar_hover: str
    # Misc
    shadow: str
    tab_active_bg: str


DARK = Theme(
    name="dark",
    bg_root="#09090b",
    bg_sidebar="#0f0f12",
    bg_card="#16161a",
    bg_surface="#1c1c21",
    bg_hover="#25252b",
    bg_input="#111114",
    bg_overlay="rgba(9, 9, 11, 0.85)",
    border="#27272a",
    border_focus="#6366f1",
    text_primary="#fafafa",
    text_secondary="#a1a1aa",
    text_muted="#71717a",
    text_dim="#52525b",
    accent="#6366f1",
    accent_hover="#818cf8",
    accent_gradient_start="#6366f1",
    accent_gradient_end="#a855f7",
    success="#10b981",
    success_bg="#10b98118",
    warning="#f59e0b",
    warning_bg="#f59e0b18",
    danger="#ef4444",
    danger_bg="#ef444418",
    info="#06b6d4",
    info_bg="#06b6d418",
    scrollbar_bg="transparent",
    scrollbar_handle="#27272a",
    scrollbar_hover="#3f3f46",
    shadow="rgba(0, 0, 0, 0.5)",
    tab_active_bg="#1c1c21",
)

LIGHT = Theme(
    name="light",
    bg_root="#fafafa",
    bg_sidebar="#f4f4f5",
    bg_card="#ffffff",
    bg_surface="#f9f9fb",
    bg_hover="#e4e4e7",
    bg_input="#ffffff",
    bg_overlay="rgba(250, 250, 250, 0.90)",
    border="#e4e4e7",
    border_focus="#6366f1",
    text_primary="#09090b",
    text_secondary="#52525b",
    text_muted="#71717a",
    text_dim="#a1a1aa",
    accent="#6366f1",
    accent_hover="#4f46e5",
    accent_gradient_start="#6366f1",
    accent_gradient_end="#a855f7",
    success="#10b981",
    success_bg="#10b98115",
    warning="#f59e0b",
    warning_bg="#f59e0b15",
    danger="#ef4444",
    danger_bg="#ef444415",
    info="#06b6d4",
    info_bg="#06b6d415",
    scrollbar_bg="transparent",
    scrollbar_handle="#d4d4d8",
    scrollbar_hover="#a1a1aa",
    shadow="rgba(0, 0, 0, 0.08)",
    tab_active_bg="#ffffff",
)

# Backward compat exports (dark as default)
BG_DEEPEST = DARK.bg_root
BG_DARKEST = DARK.bg_root
BG_DARK = DARK.bg_sidebar
BG_PANEL = DARK.bg_sidebar
BG_CARD = DARK.bg_card
BG_RAISED = DARK.bg_surface
BG_HOVER = DARK.bg_hover
BORDER = DARK.border
BORDER_ACCENT = DARK.border_focus
BORDER_GLOW = DARK.border
TEXT_PRIMARY = DARK.text_primary
TEXT_SECONDARY = DARK.text_secondary
TEXT_MUTED = DARK.text_muted
TEXT_DIM = DARK.text_dim
ACCENT_BLUE = DARK.accent
ACCENT_CYAN = DARK.info
ACCENT_GREEN = DARK.success
ACCENT_RED = DARK.danger
ACCENT_ORANGE = DARK.warning
ACCENT_PURPLE = "#a855f7"
GLOW_BLUE = DARK.accent


def get_stylesheet(theme: Theme = DARK) -> str:
    t = theme
    return f"""
    * {{
        font-family: 'Inter', 'SF Pro Display', '-apple-system', 'Segoe UI', sans-serif;
        outline: none;
    }}
    QMainWindow {{
        background-color: {t.bg_root};
        color: {t.text_primary};
    }}
    QWidget {{
        background-color: transparent;
        color: {t.text_primary};
        font-size: 13px;
    }}

    /* ═══ TOP BAR ═══ */
    #TopBar {{
        background-color: {t.bg_sidebar};
        border-bottom: 1px solid {t.border};
        min-height: 52px;
        max-height: 52px;
        padding: 0 20px;
    }}
    #TopBar QLabel {{
        color: {t.text_secondary};
        font-size: 12px;
        background: transparent;
    }}
    #ServerTitle {{
        color: {t.text_primary};
        font-weight: 700;
        font-size: 15px;
        letter-spacing: -0.3px;
    }}
    #StatusDot {{
        color: {t.success};
        font-size: 10px;
    }}
    #AddressLabel {{
        color: {t.text_dim};
        font-size: 11px;
    }}

    /* ═══ STAT BADGES ═══ */
    #StatsBadge {{
        background-color: {t.bg_card};
        border: 1px solid {t.border};
        border-radius: 16px;
        padding: 4px 14px;
        margin: 0 3px;
    }}
    #StatsBadgeIcon {{
        background: transparent;
    }}
    #StatsBadgeLabel {{
        color: {t.text_dim};
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.3px;
        background: transparent;
    }}
    #StatsBadgeValue {{
        font-weight: 700;
        font-size: 12px;
        padding: 0 0 0 5px;
        background: transparent;
    }}

    /* ═══ SIDEBAR ═══ */
    #Sidebar {{
        background-color: {t.bg_sidebar};
        border-right: 1px solid {t.border};
        min-width: 230px;
        max-width: 240px;
    }}
    #SidebarHeader {{
        color: {t.text_muted};
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.6px;
        padding: 16px 16px 8px 16px;
        background: transparent;
    }}
    #ClientCount {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
        color: white;
        font-size: 10px;
        font-weight: 700;
        border-radius: 8px;
        padding: 2px 8px;
        min-width: 16px;
    }}
    #ClientList {{
        background-color: transparent;
        border: none;
        outline: none;
        padding: 4px 8px;
    }}
    #ClientList::item {{
        border: none;
        border-radius: 10px;
        margin: 1px 0;
        padding: 0;
    }}
    #ClientList::item:selected {{
        background: {t.bg_hover};
    }}
    #ClientList::item:hover:!selected {{
        background: {t.bg_surface};
    }}

    #SidebarItem {{
        background: transparent;
        border: none;
        border-radius: 10px;
        padding: 8px 12px;
    }}
    #SidebarItem[selected="true"] {{
        background: {t.bg_hover};
    }}
    #SidebarItemIcon {{
        background: transparent;
    }}
    #SidebarItemName {{
        color: {t.text_primary};
        font-weight: 600;
        font-size: 13px;
        background: transparent;
    }}
    #SidebarItemDot {{
        font-size: 8px;
        background: transparent;
    }}
    #SidebarItemMeta {{
        color: {t.text_dim};
        font-size: 11px;
        background: transparent;
    }}
    #EmptyPlaceholder {{
        color: {t.text_dim};
        font-size: 12px;
        padding: 16px;
        background: transparent;
    }}

    /* ═══ THEME TOGGLE ═══ */
    #ThemeToggle {{
        background: {t.bg_card};
        border: 1px solid {t.border};
        border-radius: 8px;
        padding: 6px 8px;
        margin: 8px 12px;
    }}
    #ThemeToggle:hover {{
        background: {t.bg_hover};
        border-color: {t.accent};
    }}

    /* ═══ SCREEN VIEWER ═══ */
    #ScreenViewer {{
        background-color: {t.bg_root};
        border-radius: 16px;
        border: 1px solid {t.border};
        margin: 8px;
    }}
    #PlaceholderLabel {{
        color: {t.text_secondary};
        font-size: 20px;
        font-weight: 600;
        letter-spacing: -0.3px;
        background: transparent;
    }}
    #PlaceholderSub {{
        color: {t.text_dim};
        font-size: 13px;
        padding-top: 6px;
        background: transparent;
    }}
    #PlaceholderIcon {{
        background: transparent;
    }}

    #StreamOverlay {{
        background-color: {t.bg_overlay};
        border: 1px solid {t.border};
        border-radius: 10px;
        padding: 8px 12px;
        font-size: 11px;
        font-family: 'SF Mono', 'JetBrains Mono', 'Menlo', monospace;
    }}
    #OverlayClient {{
        color: {t.text_primary};
        font-weight: 600;
        font-size: 11px;
    }}
    #OverlayMetric {{
        color: {t.text_secondary};
        font-size: 10px;
        font-weight: 600;
    }}

    /* ═══ RIGHT PANEL ═══ */
    #RightPanel {{
        background-color: {t.bg_sidebar};
        border-left: 1px solid {t.border};
        min-width: 290px;
    }}
    #RightTabs {{
        background: {t.bg_sidebar};
        border: none;
    }}
    #RightTabs::pane {{
        border: none;
        border-top: 1px solid {t.border};
        background: {t.bg_sidebar};
    }}
    #RightTabs QTabBar {{
        background: {t.bg_sidebar};
    }}
    #RightTabs QTabBar::tab {{
        background: transparent;
        color: {t.text_dim};
        border: none;
        border-bottom: 2px solid transparent;
        padding: 10px 8px;
        margin: 0 1px;
        min-width: 36px;
        font-size: 11px;
        font-weight: 600;
    }}
    #RightTabs QTabBar::tab:selected {{
        color: {t.accent};
        border-bottom: 2px solid {t.accent};
    }}
    #RightTabs QTabBar::tab:hover:!selected {{
        color: {t.text_secondary};
    }}
    #RightTabScroll {{
        background: transparent;
        border: none;
    }}
    #RightTabScroll > QWidget > QWidget {{
        background: transparent;
    }}

    #SectionHeader {{
        color: {t.text_muted};
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.8px;
        padding: 12px 12px 8px 12px;
        background: transparent;
    }}

    /* ═══ CHAT ═══ */
    #ChatPanel {{ background: transparent; border: none; }}
    #ChatHistory {{
        background: transparent;
        border: none;
        color: {t.text_primary};
        font-size: 12px;
        padding: 8px 12px;
    }}
    #ChatInput {{
        background-color: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 10px;
        color: {t.text_primary};
        padding: 10px 14px;
        font-size: 13px;
        margin: 0 12px 12px 12px;
        selection-background-color: {t.accent};
    }}
    #ChatInput:focus {{
        border-color: {t.accent};
    }}

    /* ═══ CONTROLS ═══ */
    #ControlPanel {{ padding: 4px 8px 12px 8px; }}
    #NetworkGraph {{
        background: {t.bg_card};
        border: 1px solid {t.border};
        border-radius: 10px;
        margin: 4px 8px;
    }}

    /* ═══ TRANSFER ═══ */
    #TransferPanel {{ background: transparent; border: none; }}
    #TransferStatus {{
        color: {t.text_secondary};
        font-size: 12px;
        padding: 0 8px;
    }}
    #TransferQueueTable {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 8px;
        gridline-color: {t.border};
        selection-background-color: {t.bg_hover};
        font-size: 11px;
        color: {t.text_primary};
        margin: 0 8px;
    }}
    #TransferQueueTable QHeaderView::section {{
        background: {t.bg_card};
        color: {t.text_dim};
        border: none;
        border-bottom: 1px solid {t.border};
        padding: 6px 8px;
        font-size: 10px;
        font-weight: 700;
    }}

    /* ═══ SCANNER ═══ */
    #NetworkScannerPanel {{ background: transparent; border: none; }}
    #ScannerSubnetInput, #ScannerPortFilter {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 8px;
        color: {t.text_primary};
        padding: 7px 10px;
        font-size: 12px;
    }}
    #ScannerSubnetInput:focus, #ScannerPortFilter:focus {{
        border-color: {t.accent};
    }}
    #ScannerHistoryCombo {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 8px;
        color: {t.text_primary};
        padding: 5px 8px;
    }}
    #ScannerActiveOnly {{
        color: {t.text_secondary};
        font-size: 12px;
        spacing: 6px;
    }}
    #ScannerActiveOnly::indicator {{
        width: 16px; height: 16px;
        border-radius: 4px;
        border: 1px solid {t.border};
        background: {t.bg_input};
    }}
    #ScannerActiveOnly::indicator:checked {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
        border: none;
    }}
    #ScannerNote {{
        color: {t.text_dim};
        font-size: 11px;
        padding: 0 4px;
    }}
    #ScannerStatus {{
        color: {t.text_secondary};
        font-size: 11px;
        font-weight: 600;
    }}
    #ScannerTable {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 8px;
        gridline-color: {t.border};
        selection-background-color: {t.bg_hover};
        font-size: 12px;
        color: {t.text_primary};
    }}
    #ScannerTable QHeaderView::section {{
        background: {t.bg_card};
        color: {t.text_dim};
        border: none;
        border-bottom: 1px solid {t.border};
        padding: 6px 8px;
        font-size: 10px;
        font-weight: 700;
    }}

    /* ═══ AUDIT ═══ */
    #AuditLogPanel {{ background: transparent; border: none; }}
    #AuditLogView {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 8px;
        color: {t.text_primary};
        font-size: 11px;
        padding: 8px 10px;
        margin: 0 8px 8px 8px;
        font-family: 'SF Mono', 'JetBrains Mono', 'Menlo', monospace;
    }}

    /* ═══ PROGRESS BAR (gradient) ═══ */
    QProgressBar {{
        background: {t.bg_input};
        border: 1px solid {t.border};
        border-radius: 6px;
        min-height: 14px;
        max-height: 14px;
        text-align: center;
        color: {t.text_primary};
        font-size: 10px;
        margin: 0 8px 8px 8px;
    }}
    QProgressBar::chunk {{
        border-radius: 5px;
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
    }}

    /* ═══ BUTTONS ═══ */
    QPushButton {{
        border: none;
        border-radius: 8px;
        padding: 9px 18px;
        font-weight: 600;
        font-size: 13px;
        color: white;
        min-height: 20px;
    }}
    QPushButton#BtnLock {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #f59e0b,stop:1 #f97316);
    }}
    QPushButton#BtnLock:hover {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #fbbf24,stop:1 #fb923c);
    }}
    QPushButton#BtnShutdown {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #ef4444,stop:1 #f43f5e);
    }}
    QPushButton#BtnShutdown:hover {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #f87171,stop:1 #fb7185);
    }}
    QPushButton#BtnRestart {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
    }}
    QPushButton#BtnRestart:hover {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_hover},stop:1 #c084fc);
    }}
    QPushButton#BtnSend {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
    }}
    QPushButton#BtnSend:hover {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_hover},stop:1 #c084fc);
    }}
    QPushButton:disabled {{
        background: {t.bg_card};
        color: {t.text_dim};
        border: 1px solid {t.border};
    }}

    QPushButton#BtnTransferCancel, QPushButton#BtnTransferRetry,
    QPushButton#BtnScannerExport, QPushButton#BtnScannerStop {{
        background: {t.bg_card};
        border: 1px solid {t.border};
        color: {t.text_secondary};
        padding: 7px 14px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
    }}
    QPushButton#BtnTransferCancel:hover, QPushButton#BtnTransferRetry:hover,
    QPushButton#BtnScannerExport:hover, QPushButton#BtnScannerStop:hover {{
        background: {t.bg_hover};
        color: {t.text_primary};
    }}
    QPushButton#BtnScannerStart {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_gradient_start},stop:1 {t.accent_gradient_end});
        color: white;
        padding: 7px 14px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
    }}
    QPushButton#BtnScannerStart:hover {{
        background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {t.accent_hover},stop:1 #c084fc);
    }}

    /* ═══ COLLAPSE TOGGLE ═══ */
    #CollapseToggle {{
        background: {t.bg_card};
        border: 1px solid {t.border};
        border-radius: 6px;
        color: {t.text_dim};
        font-size: 14px;
        padding: 4px 6px;
        min-width: 24px; max-width: 24px;
        min-height: 24px; max-height: 24px;
    }}
    #CollapseToggle:hover {{
        background: {t.bg_hover};
        color: {t.accent};
    }}

    /* ═══ SCROLLBARS ═══ */
    QScrollBar:vertical {{
        background: {t.scrollbar_bg};
        width: 5px;
        margin: 4px 1px;
        border-radius: 2px;
    }}
    QScrollBar::handle:vertical {{
        background: {t.scrollbar_handle};
        min-height: 30px;
        border-radius: 2px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {t.scrollbar_hover};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
    QScrollBar:horizontal {{ height: 0; }}

    /* ═══ SPLITTER ═══ */
    QSplitter {{ background-color: {t.bg_root}; }}
    QSplitter::handle {{ background-color: {t.border}; width: 1px; }}

    /* ═══ TOOLTIPS ═══ */
    QToolTip {{
        background: {t.bg_card};
        color: {t.text_primary};
        border: 1px solid {t.border};
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 12px;
    }}

    /* ═══ DIALOGS ═══ */
    QMessageBox {{
        background: {t.bg_sidebar};
    }}
    QMessageBox QLabel {{
        color: {t.text_primary};
        font-size: 13px;
        padding: 8px;
        background: transparent;
    }}
    QMessageBox QPushButton {{
        background: {t.bg_card};
        border: 1px solid {t.border};
        min-width: 80px;
        padding: 8px 20px;
    }}
    QMessageBox QPushButton:hover {{
        background: {t.bg_hover};
        border-color: {t.accent};
    }}
    """
