#!/usr/bin/env python3
"""
Remote Desktop Manager — Cinematic Server UI

Premium dual-theme PyQt6 dashboard with vibrant gradient accents,
icons throughout, and dark/light mode toggle.

Usage:
    python server_ui.py --host 0.0.0.0 --port 5000 --password lan-demo-123
"""

import argparse, csv, ipaddress, json, os, socket, subprocess, sys
import threading, time
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, List, Optional

from PyQt6.QtCore import Qt, QSize, pyqtSignal, QTimer
from PyQt6.QtGui import QImage, QPixmap, QFont, QColor, QPainter, QPen, QIcon
from PyQt6.QtWidgets import (
    QApplication, QFrame, QHeaderView, QHBoxLayout, QCheckBox, QComboBox,
    QFileDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QProgressBar, QScrollArea, QSizePolicy,
    QSplitter, QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget,
)

from rdm_project.server.core.server import RemoteManagerServer
from rdm_project.server.ui.ui_copy import UI_COPY
from rdm_project.server.ui.ui_bridge import ServerBridge
from rdm_project.server.ui.theme import (
    DARK, LIGHT, Theme, get_stylesheet,
    ACCENT_BLUE, ACCENT_CYAN, ACCENT_GREEN, ACCENT_ORANGE, ACCENT_RED,
    ACCENT_PURPLE, BG_CARD, BG_DARK, BG_DARKEST, BG_DEEPEST, BG_PANEL,
    BG_RAISED, BG_HOVER, BORDER, BORDER_ACCENT, TEXT_DIM, TEXT_MUTED,
    TEXT_PRIMARY, TEXT_SECONDARY,
)

# ─── Global theme state ──────────────────────────────────────────────────────
_current_theme: Theme = DARK

def current_theme() -> Theme:
    return _current_theme

# ─── Utilities ────────────────────────────────────────────────────────────────
def _latency_color(ms: float) -> str:
    t = current_theme()
    if ms < 50: return t.success
    if ms <= 100: return t.warning
    return t.danger

def _fps_color(fps: float) -> str:
    t = current_theme()
    if fps > 3: return t.success
    if fps >= 1: return t.warning
    return t.danger

def _human_bytes(n: int) -> str:
    v = float(max(0, n))
    for u in ["B", "KB", "MB", "GB"]:
        if v < 1024: return f"{int(v)} {u}" if u == "B" else f"{v:.1f} {u}"
        v /= 1024
    return f"{v:.1f} TB"

def _format_transfer_label(label: str) -> str:
    if label.endswith(" bytes") and "/" in label:
        try:
            d, t = label[:-6].strip().split("/", 1)
            return f"{_human_bytes(int(d.strip()))} / {_human_bytes(int(t.strip()))}"
        except Exception: pass
    return label

def _format_transfer_rate(bps: float) -> str:
    v = max(0.0, float(bps))
    for u in ["B/s", "KB/s", "MB/s", "GB/s"]:
        if v < 1024: return f"{v:.1f} {u}"
        v /= 1024
    return f"{v:.1f} TB/s"

def _audit_ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _icons_dir() -> str:
    return os.path.join(os.path.dirname(__file__), "icons")

def _icon(name: str) -> QIcon:
    path = os.path.join(_icons_dir(), f"{name}.svg")
    if os.path.isfile(path):
        return QIcon(path)
    return QIcon()


# ═══════════════════════════════════════════════════════════════════════════════
#  StatsBadge — Pill stat for top bar
# ═══════════════════════════════════════════════════════════════════════════════
class StatsBadge(QFrame):
    def __init__(self, label: str, initial: str = "—", icon_name: Optional[str] = None, parent=None):
        super().__init__(parent)
        self.setObjectName("StatsBadge")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        if icon_name:
            ic = QLabel()
            ic.setObjectName("StatsBadgeIcon")
            ic.setPixmap(_icon(icon_name).pixmap(QSize(13, 13)))
            ic.setFixedSize(15, 15)
            lay.addWidget(ic)
        self._label = QLabel(label)
        self._label.setObjectName("StatsBadgeLabel")
        lay.addWidget(self._label)
        self._value = QLabel(initial)
        self._value.setObjectName("StatsBadgeValue")
        lay.addWidget(self._value)
        self._last_text = initial
        self._last_color = ""

    def set_value(self, text: str, color: str = ""):
        if text != self._last_text:
            self._value.setText(text)
            self._last_text = text
        if color and color != self._last_color:
            self._value.setStyleSheet(f"color:{color};font-weight:700;font-size:12px;padding:0 0 0 5px;background:transparent;")
            self._last_color = color

StatChip = StatsBadge


# ═══════════════════════════════════════════════════════════════════════════════
#  StatsBar — Top bar
# ═══════════════════════════════════════════════════════════════════════════════
class StatsBar(QFrame):
    def __init__(self, host: str, port: int, parent=None):
        super().__init__(parent)
        self.setObjectName("TopBar")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(20, 0, 20, 0)
        lay.setSpacing(10)

        dot = QLabel("●")
        dot.setObjectName("StatusDot")
        dot.setFixedWidth(14)
        lay.addWidget(dot)

        title = QLabel(UI_COPY["app_title"])
        title.setObjectName("ServerTitle")
        lay.addWidget(title)

        addr = QLabel(f"{host}:{port}")
        addr.setObjectName("AddressLabel")
        lay.addWidget(addr)
        lay.addStretch()

        self.chip_clients = StatsBadge(UI_COPY["clients"], "0", "server")
        self.chip_fps     = StatsBadge(UI_COPY["fps"], "—", "zap")
        self.chip_latency = StatsBadge(UI_COPY["latency"], "—", "wifi")
        self.chip_rx      = StatsBadge(UI_COPY["rx"], "0 KB", "activity")
        self.chip_tx      = StatsBadge(UI_COPY["tx"], "0 KB", "activity")
        for c in [self.chip_clients, self.chip_fps, self.chip_latency, self.chip_rx, self.chip_tx]:
            lay.addWidget(c)

    def update_stats(self, stats: dict, selected: Optional[str]):
        t = current_theme()
        n = len(stats)
        self.chip_clients.set_value(str(n), t.info if n > 0 else t.text_dim)
        if selected and selected in stats:
            s = stats[selected]
            fps, ping = s.get("fps", 0.0), s.get("ping_ms", 0.0)
            rx, tx = s.get("bytes_recv", 0.0) / 1024, s.get("bytes_sent", 0.0) / 1024
            self.chip_fps.set_value(f"{fps:.1f}", _fps_color(fps))
            self.chip_latency.set_value(f"{ping:.0f} ms", _latency_color(ping))
            self.chip_rx.set_value(f"{rx:.0f} KB" if rx < 1024 else f"{rx/1024:.1f} MB", t.text_primary)
            self.chip_tx.set_value(f"{tx:.0f} KB" if tx < 1024 else f"{tx/1024:.1f} MB", t.text_primary)
        else:
            self.chip_fps.set_value("—", t.text_dim)
            self.chip_latency.set_value("—", t.text_dim)
            self.chip_rx.set_value("0 KB", t.text_dim)
            self.chip_tx.set_value("0 KB", t.text_dim)

TopBar = StatsBar


# ═══════════════════════════════════════════════════════════════════════════════
#  SidebarItem — Flat row with icon + dot + metrics
# ═══════════════════════════════════════════════════════════════════════════════
class SidebarItem(QFrame):
    def __init__(self, client_id: str, parent=None):
        super().__init__(parent)
        self.setObjectName("SidebarItem")
        self._client_id = client_id

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(10)

        # Icon
        self.icon_label = QLabel()
        self.icon_label.setObjectName("SidebarItemIcon")
        self.icon_label.setPixmap(_icon("monitor").pixmap(QSize(18, 18)))
        self.icon_label.setFixedSize(20, 20)
        lay.addWidget(self.icon_label)

        # Text column
        text_col = QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(1)

        name_row = QHBoxLayout()
        name_row.setContentsMargins(0, 0, 0, 0)
        name_row.setSpacing(6)
        self.name_label = QLabel(client_id)
        self.name_label.setObjectName("SidebarItemName")
        name_row.addWidget(self.name_label, stretch=1)
        self.status_dot = QLabel("●")
        self.status_dot.setObjectName("SidebarItemDot")
        self.status_dot.setFixedWidth(12)
        name_row.addWidget(self.status_dot)
        text_col.addLayout(name_row)

        self.meta_label = QLabel("—")
        self.meta_label.setObjectName("SidebarItemMeta")
        text_col.addWidget(self.meta_label)

        lay.addLayout(text_col, stretch=1)

    def set_metrics(self, cpu_pct: float, ram_pct: float, latency_ms: float, online: bool):
        t = current_theme()
        dot_color = t.success if online else t.danger
        self.status_dot.setStyleSheet(f"color:{dot_color};font-size:8px;background:transparent;")
        self.meta_label.setText(f"CPU {cpu_pct:.0f}% • RAM {ram_pct:.0f}% • {latency_ms:.0f}ms")

    def set_selected(self, selected: bool):
        self.setProperty("selected", selected)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

ClientCard = SidebarItem


# ═══════════════════════════════════════════════════════════════════════════════
#  ClientListPanel — Sidebar
# ═══════════════════════════════════════════════════════════════════════════════
class ClientListPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self._client_health: Dict[str, dict] = {}
        self._last_clients: List[str] = []
        self._item_by_client: Dict[str, QListWidgetItem] = {}
        self._card_by_client: Dict[str, SidebarItem] = {}

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(16, 16, 16, 8)
        hdr = QLabel(UI_COPY["connected"])
        hdr.setObjectName("SidebarHeader")
        hdr_row.addWidget(hdr)
        hdr_row.addStretch()
        self.count_label = QLabel("0")
        self.count_label.setObjectName("ClientCount")
        hdr_row.addWidget(self.count_label)
        lay.addLayout(hdr_row)

        self.client_list = QListWidget()
        self.client_list.setObjectName("ClientList")
        self.client_list.setIconSize(QSize(0, 0))
        lay.addWidget(self.client_list, stretch=1)

        self.placeholder = QLabel(UI_COPY["waiting"])
        self.placeholder.setObjectName("EmptyPlaceholder")
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.placeholder.setWordWrap(True)
        lay.addWidget(self.placeholder, stretch=1)

    def update_health(self, health, selected=None):
        self._client_health = dict(health)
        self._refresh(selected)

    def update_clients(self, client_ids, selected=None):
        desired = list(client_ids)
        if desired != self._last_clients:
            self.client_list.clear()
            self._item_by_client.clear()
            self._card_by_client.clear()
            for cid in desired:
                item = QListWidgetItem()
                item.setData(Qt.ItemDataRole.UserRole, cid)
                item.setSizeHint(QSize(0, 54))
                item.setToolTip(f"View {cid}")
                self.client_list.addItem(item)
                card = SidebarItem(cid)
                self.client_list.setItemWidget(item, card)
                self._item_by_client[cid] = item
                self._card_by_client[cid] = card
            self._last_clients = desired
        n = len(self._last_clients)
        self.count_label.setText(str(n))
        self.placeholder.setVisible(n == 0)
        self.client_list.setVisible(n > 0)
        self._refresh(selected)
        if selected and selected in self._item_by_client:
            it = self._item_by_client[selected]
            it.setSelected(True)
            self.client_list.setCurrentItem(it)

    def _refresh(self, selected=None):
        for cid in self._last_clients:
            h = self._client_health.get(cid, {})
            card = self._card_by_client.get(cid)
            if not card: continue
            card.set_metrics(
                float(h.get("cpu_pct", 0)), float(h.get("ram_pct", 0)),
                float(h.get("ping_ms", 0)),
                float(h.get("last_seen", 0)) > 0 and (time.time() - float(h.get("last_seen", 0))) < 5.0)
            card.set_selected(cid == selected)


# ═══════════════════════════════════════════════════════════════════════════════
#  StreamOverlay + ScreenViewer
# ═══════════════════════════════════════════════════════════════════════════════
class StreamOverlay(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("StreamOverlay")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(2)
        self.client_label = QLabel("—")
        self.client_label.setObjectName("OverlayClient")
        lay.addWidget(self.client_label)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        self.fps_label = QLabel("FPS: —")
        self.fps_label.setObjectName("OverlayMetric")
        row.addWidget(self.fps_label)
        self.latency_label = QLabel("RTT: —")
        self.latency_label.setObjectName("OverlayMetric")
        row.addWidget(self.latency_label)
        lay.addLayout(row)

    def update_stats(self, client_id: str, fps: float, latency_ms: float):
        self.client_label.setText(client_id)
        fc, lc = _fps_color(fps), _latency_color(latency_ms)
        self.fps_label.setText(f"FPS: <span style='color:{fc};font-weight:700'>{fps:.1f}</span>")
        self.latency_label.setText(f"RTT: <span style='color:{lc};font-weight:700'>{latency_ms:.0f}ms</span>")


class ScreenViewer(QFrame):
    file_dropped = pyqtSignal(str)
    files_dropped = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ScreenViewer")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(0)

        orow = QHBoxLayout()
        orow.setContentsMargins(0, 0, 0, 0)
        self.hud_overlay = StreamOverlay()
        self.hud_overlay.setVisible(False)
        orow.addWidget(self.hud_overlay, alignment=Qt.AlignmentFlag.AlignLeft)
        orow.addStretch(1)
        lay.addLayout(orow)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setMinimumSize(320, 240)
        self.image_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        lay.addWidget(self.image_label, stretch=1)

        # Placeholder
        pc = QVBoxLayout()
        pc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.setSpacing(12)

        self.placeholder_icon = QLabel()
        self.placeholder_icon.setObjectName("PlaceholderIcon")
        self.placeholder_icon.setPixmap(_icon("monitor").pixmap(QSize(48, 48)))
        self.placeholder_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder_icon.setFixedSize(56, 56)
        pc.addWidget(self.placeholder_icon, alignment=Qt.AlignmentFlag.AlignCenter)

        self.placeholder = QLabel(UI_COPY["empty_title"])
        self.placeholder.setObjectName("PlaceholderLabel")
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.addWidget(self.placeholder)

        self.placeholder_sub = QLabel(UI_COPY["empty_subtitle"])
        self.placeholder_sub.setObjectName("PlaceholderSub")
        self.placeholder_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.addWidget(self.placeholder_sub)

        self._placeholder_widget = QWidget()
        self._placeholder_widget.setLayout(pc)
        lay.addWidget(self._placeholder_widget, stretch=1)

        self.image_label.setVisible(False)
        self._placeholder_widget.setVisible(True)
        self.setAcceptDrops(True)

    def show_frame(self, img: QImage):
        self._placeholder_widget.setVisible(False)
        self.image_label.setVisible(True)
        self.hud_overlay.setVisible(True)
        scaled = QPixmap.fromImage(img).scaled(
            self.image_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self.image_label.setPixmap(scaled)

    def update_hud(self, client_id: str, fps: float, latency_ms: float):
        self.hud_overlay.update_stats(client_id, fps, latency_ms)

    def clear_frame(self):
        self.image_label.clear()
        self.image_label.setVisible(False)
        self.hud_overlay.setVisible(False)
        self._placeholder_widget.setVisible(True)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and urls[0].isLocalFile() and os.path.isfile(urls[0].toLocalFile()):
                event.acceptProposedAction(); return
        event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls: event.ignore(); return
        paths = [u.toLocalFile() for u in urls if u.isLocalFile() and os.path.isfile(u.toLocalFile())]
        if paths:
            self.file_dropped.emit(paths[0])
            self.files_dropped.emit(paths)
            event.acceptProposedAction()
        else: event.ignore()


# ═══════════════════════════════════════════════════════════════════════════════
#  NetworkGraph
# ═══════════════════════════════════════════════════════════════════════════════
class NetworkGraph(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("NetworkGraph")
        self.setMinimumHeight(110)
        self._values = []
        self._max_points = 90

    def clear(self):
        self._values.clear(); self.update()

    def add_point(self, value: float):
        self._values.append(max(0.0, float(value)))
        if len(self._values) > self._max_points:
            self._values = self._values[-self._max_points:]
        self.update()

    def paintEvent(self, event):
        t = current_theme()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        outer = self.rect().adjusted(10, 8, -10, -8)
        plot = outer.adjusted(0, 16, 0, -2)
        max_val = max(120.0, max(self._values) * 1.1) if self._values else 120.0

        painter.setPen(QColor(t.text_dim))
        tf = QFont(painter.font()); tf.setPointSize(9); tf.setBold(True)
        painter.setFont(tf)
        painter.drawText(outer.left(), outer.top() + 11, "LATENCY (MS)")

        painter.setPen(QPen(QColor(t.border), 1))
        for step in range(4):
            y = plot.top() + int((plot.height() * step) / 3)
            painter.drawLine(plot.left(), y, plot.right(), y)

        lf = QFont(painter.font()); lf.setPointSize(8); lf.setBold(False)
        painter.setFont(lf)
        painter.setPen(QColor(t.text_dim))
        painter.drawText(plot.right() - 40, plot.top() + 10, f"{int(max_val)}")
        painter.drawText(plot.right() - 40, plot.top() + int(plot.height()/2) + 4, f"{int(max_val/2)}")
        painter.drawText(plot.right() - 20, plot.bottom() - 2, "0")

        if len(self._values) < 2:
            painter.drawText(plot.left() + 6, plot.center().y(), "Waiting for samples…")
            painter.end(); return

        w, h = max(1, plot.width()), max(1, plot.height())
        dx = w / max(1, len(self._values) - 1)
        latest = self._values[-1]
        color = QColor(_latency_color(latest))
        painter.setPen(QPen(color, 2.0))

        px, py = plot.left(), plot.bottom() - int((self._values[0] / max_val) * h)
        for i in range(1, len(self._values)):
            x = plot.left() + int(i * dx)
            y = plot.bottom() - int((self._values[i] / max_val) * h)
            painter.drawLine(px, py, x, y)
            px, py = x, y

        vf = QFont(painter.font()); vf.setPointSize(9); vf.setBold(True)
        painter.setFont(vf); painter.setPen(color)
        painter.drawText(plot.right() - 92, outer.top() + 11, f"{latest:.0f} ms")
        painter.end()


# ═══════════════════════════════════════════════════════════════════════════════
#  TransferPanel
# ═══════════════════════════════════════════════════════════════════════════════
class TransferPanel(QFrame):
    files_selected = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TransferPanel")
        self.setAcceptDrops(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 4, 8, 8)
        lay.setSpacing(8)

        hdr = QLabel(UI_COPY["file_transfer"])
        hdr.setObjectName("SectionHeader")
        lay.addWidget(hdr)
        self.status = QLabel(UI_COPY["file_drop"])
        self.status.setObjectName("TransferStatus")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100); self.progress.setValue(0)
        lay.addWidget(self.progress)

        self.queue_table = QTableWidget(0, 5)
        self.queue_table.setObjectName("TransferQueueTable")
        self.queue_table.setHorizontalHeaderLabels(["File", "Status", "%", "Speed", "ETA"])
        self.queue_table.verticalHeader().setVisible(False)
        self.queue_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.queue_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.queue_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.queue_table.setMinimumHeight(120)
        hv = self.queue_table.horizontalHeader()
        hv.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in range(1, 5): hv.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        lay.addWidget(self.queue_table)

        br = QHBoxLayout()
        br.setContentsMargins(0, 0, 0, 0); br.setSpacing(8)
        self.add_files_btn = QPushButton("Add Files")
        self.add_files_btn.setObjectName("BtnTransferAdd")
        self.add_files_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_files_btn.clicked.connect(self._pick_files)
        br.addWidget(self.add_files_btn)
        self.cancel_btn = QPushButton(UI_COPY["cancel_task"])
        self.cancel_btn.setObjectName("BtnTransferCancel")
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        br.addWidget(self.cancel_btn)
        self.retry_btn = QPushButton(UI_COPY["retry_task"])
        self.retry_btn.setObjectName("BtnTransferRetry")
        self.retry_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        br.addWidget(self.retry_btn)
        lay.addLayout(br)

    def set_idle(self):
        self.status.setText(UI_COPY["file_drop"]); self.progress.setValue(0)

    def set_progress(self, percent: int, text: str):
        self.status.setText(text)
        self.progress.setValue(max(0, min(100, int(percent))))

    def selected_task_id(self) -> Optional[str]:
        row = self.queue_table.currentRow()
        if row < 0: return None
        item = self.queue_table.item(row, 0)
        if not item: return None
        tid = item.data(Qt.ItemDataRole.UserRole)
        return str(tid) if tid else None

    def update_queue(self, tasks: List[dict]):
        t = current_theme()
        self.queue_table.setRowCount(0)
        for task in tasks:
            row = self.queue_table.rowCount()
            self.queue_table.insertRow(row)
            fi = QTableWidgetItem(str(task.get("file_name", "")))
            fi.setData(Qt.ItemDataRole.UserRole, str(task.get("task_id", "")))
            self.queue_table.setItem(row, 0, fi)
            st = str(task.get("status", "queued"))
            si = QTableWidgetItem(st)
            cm = {"done": t.success, "in_progress": t.info, "failed": t.danger, "cancelled": t.danger}
            si.setForeground(QColor(cm.get(st, t.text_secondary)))
            self.queue_table.setItem(row, 1, si)
            self.queue_table.setItem(row, 2, QTableWidgetItem(str(int(task.get("percent", 0)))))
            spd = float(task.get("speed_bps", 0))
            self.queue_table.setItem(row, 3, QTableWidgetItem("—" if spd <= 0 else _format_transfer_rate(spd)))
            eta = float(task.get("eta_s", 0))
            self.queue_table.setItem(row, 4, QTableWidgetItem("—" if eta <= 0 else f"{eta:.1f}s"))

    def _pick_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Select files to transfer")
        if paths:
            self.files_selected.emit([str(p) for p in paths if p])

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
            if any(os.path.isfile(p) for p in paths):
                event.acceptProposedAction()
                return
        event.ignore()

    def dropEvent(self, event):
        if not event.mimeData().hasUrls():
            event.ignore()
            return
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile() and os.path.isfile(u.toLocalFile())]
        if paths:
            self.files_selected.emit(paths)
            event.acceptProposedAction()
            return
        event.ignore()


# ═══════════════════════════════════════════════════════════════════════════════
#  NetworkScannerPanel
# ═══════════════════════════════════════════════════════════════════════════════
class NetworkScannerPanel(QFrame):
    _row_ready = pyqtSignal(str, str, str)
    _scan_finished = pyqtSignal(str)
    audit_event = pyqtSignal(str)
    COMMON_PORTS = (22, 80, 443, 3389)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("NetworkScannerPanel")
        self._scan_thread = None
        self._cancel = threading.Event()
        self._scan_rows = []
        self._history = deque(maxlen=8)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 4, 8, 8)
        lay.setSpacing(8)
        hdr = QLabel(UI_COPY["network_scanner"])
        hdr.setObjectName("SectionHeader")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.setContentsMargins(0, 0, 0, 0); ctrl.setSpacing(8)
        self.subnet_input = QLineEdit()
        self.subnet_input.setObjectName("ScannerSubnetInput")
        self.subnet_input.setPlaceholderText("192.168.1.0/24")
        self.subnet_input.setText(self._default_subnet())
        ctrl.addWidget(self.subnet_input, stretch=1)
        self.scan_btn = QPushButton(UI_COPY["scan"])
        self.scan_btn.setObjectName("BtnScannerStart")
        self.scan_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.scan_btn.setIcon(_icon("search"))
        ctrl.addWidget(self.scan_btn)
        self.stop_btn = QPushButton(UI_COPY["stop"])
        self.stop_btn.setObjectName("BtnScannerStop")
        self.stop_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.stop_btn.setEnabled(False)
        ctrl.addWidget(self.stop_btn)
        lay.addLayout(ctrl)

        self.note = QLabel(UI_COPY["scanner_note"])
        self.note.setObjectName("ScannerNote"); self.note.setWordWrap(True)
        lay.addWidget(self.note)

        filt = QHBoxLayout()
        filt.setContentsMargins(0, 0, 0, 0); filt.setSpacing(8)
        self.active_only = QCheckBox(UI_COPY["active_only"])
        self.active_only.setObjectName("ScannerActiveOnly")
        filt.addWidget(self.active_only)
        self.port_filter = QLineEdit()
        self.port_filter.setObjectName("ScannerPortFilter")
        self.port_filter.setPlaceholderText(UI_COPY["filter_port"])
        filt.addWidget(self.port_filter, stretch=1)
        lay.addLayout(filt)

        er = QHBoxLayout()
        er.setContentsMargins(0, 0, 0, 0); er.setSpacing(8)
        self.export_csv_btn = QPushButton(UI_COPY["export_csv"])
        self.export_csv_btn.setObjectName("BtnScannerExport")
        er.addWidget(self.export_csv_btn)
        self.export_json_btn = QPushButton(UI_COPY["export_json"])
        self.export_json_btn.setObjectName("BtnScannerExport")
        er.addWidget(self.export_json_btn)
        lay.addLayout(er)

        hr = QHBoxLayout()
        hr.setContentsMargins(0, 0, 0, 0); hr.setSpacing(8)
        self.history_combo = QComboBox()
        self.history_combo.setObjectName("ScannerHistoryCombo")
        self.history_combo.addItem(UI_COPY["latest_run"])
        hr.addWidget(self.history_combo, stretch=1)
        self.compare_btn = QPushButton(UI_COPY["compare_runs"])
        self.compare_btn.setObjectName("BtnScannerExport")
        hr.addWidget(self.compare_btn)
        lay.addLayout(hr)

        self.table = QTableWidget(0, 3)
        self.table.setObjectName("ScannerTable")
        self.table.setHorizontalHeaderLabels(["IP", "Status", "Open Ports"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setMinimumHeight(160)
        self.table.setSortingEnabled(True)
        thv = self.table.horizontalHeader()
        thv.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        thv.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        thv.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        lay.addWidget(self.table)

        self.status = QLabel(UI_COPY["ready_scan"])
        self.status.setObjectName("ScannerStatus")
        lay.addWidget(self.status)

        self.scan_btn.clicked.connect(self.start_scan)
        self.stop_btn.clicked.connect(self.stop_scan)
        self._row_ready.connect(self._add_row)
        self._scan_finished.connect(self._on_scan_finished)
        self.active_only.toggled.connect(self._apply_filters)
        self.port_filter.textChanged.connect(self._apply_filters)
        self.export_csv_btn.clicked.connect(lambda: self._export_results("csv"))
        self.export_json_btn.clicked.connect(lambda: self._export_results("json"))
        self.compare_btn.clicked.connect(self._compare_with_history)

    def _default_subnet(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]
            p = ip.split(".")
            if len(p) == 4: return f"{p[0]}.{p[1]}.{p[2]}.0/24"
        except Exception: pass
        return "192.168.1.0/24"

    def _validate_lan(self, cidr):
        net = ipaddress.ip_network(cidr, strict=False)
        if net.version != 4: raise ValueError("IPv4 only")
        if not net.is_private: raise ValueError("LAN only")
        if net.prefixlen < 24: raise ValueError("/24 or smaller")
        return net

    def start_scan(self):
        if self._scan_thread and self._scan_thread.is_alive(): return
        try: net = self._validate_lan(self.subnet_input.text().strip())
        except Exception as e: QMessageBox.warning(self, UI_COPY["invalid_subnet"], str(e)); return
        self.table.setRowCount(0); self._scan_rows = []
        self.status.setText(f"Scanning {net.with_prefixlen}…")
        self.audit_event.emit(f"scan_start subnet={net.with_prefixlen}")
        self.scan_btn.setEnabled(False); self.stop_btn.setEnabled(True)
        self.subnet_input.setEnabled(False); self._cancel.clear()
        self._scan_thread = threading.Thread(target=self._scan_worker, args=(net,), daemon=True)
        self._scan_thread.start()

    def stop_scan(self):
        self._cancel.set(); self.status.setText(UI_COPY["stopping_scan"])
        self.stop_btn.setEnabled(False)
        self.audit_event.emit("scan_stop")

    def _scan_worker(self, net):
        hosts = [str(ip) for ip in net.hosts()][:254]
        found, processed = 0, 0
        with ThreadPoolExecutor(max_workers=24) as pool:
            futures = {pool.submit(self._scan_host, ip): ip for ip in hosts}
            for f in as_completed(futures):
                if self._cancel.is_set(): break
                try: ip, st, ports = f.result()
                except Exception: continue
                processed += 1
                if st == "Active": found += 1
                self._row_ready.emit(ip, st, ports)
        prefix = "Stopped" if self._cancel.is_set() else "Complete"
        self._scan_finished.emit(f"{prefix}. {processed} hosts, {found} active.")

    def _scan_host(self, ip):
        open_ports, active = [], False
        for port in self.COMMON_PORTS:
            if self._cancel.is_set(): break
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.25)
                if s.connect_ex((ip, port)) == 0: open_ports.append(port); active = True
        if not active and not self._cancel.is_set(): active = self._ping(ip)
        st = "Active" if active else "No response"
        pt = ", ".join(str(p) for p in open_ports) if open_ports else ("None" if active else "—")
        return ip, st, pt

    def _ping(self, ip):
        try:
            return subprocess.run(["ping", "-c", "1", "-W", "1000", ip],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1.5, check=False).returncode == 0
        except Exception: return False

    def _add_row(self, ip, status, ports):
        t = current_theme()
        self._scan_rows.append({"ip": ip, "status": status, "open_ports": ports})
        row = self.table.rowCount(); self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(ip))
        si = QTableWidgetItem(status)
        si.setForeground(QColor(t.success if status == "Active" else t.text_dim))
        self.table.setItem(row, 1, si)
        self.table.setItem(row, 2, QTableWidgetItem(ports))
        self._apply_filters()

    def _on_scan_finished(self, summary):
        self.scan_btn.setEnabled(True); self.stop_btn.setEnabled(False)
        self.subnet_input.setEnabled(True); self.status.setText(summary)
        snap = {"timestamp": _audit_ts(), "subnet": self.subnet_input.text().strip(), "rows": list(self._scan_rows)}
        self._history.appendleft(snap); self._refresh_history_combo()
        self.audit_event.emit(f"scan_done {summary}")

    def _refresh_history_combo(self):
        self.history_combo.clear()
        self.history_combo.addItem(UI_COPY["latest_run"], None)
        for i, item in enumerate(self._history):
            self.history_combo.addItem(f"{i+1}. {item['timestamp']} ({item['subnet']})", i)

    def _apply_filters(self):
        ao, pt = self.active_only.isChecked(), self.port_filter.text().strip()
        for row in range(self.table.rowCount()):
            si, pi = self.table.item(row, 1), self.table.item(row, 2)
            st = si.text() if si else ""
            ports = pi.text() if pi else ""
            self.table.setRowHidden(row, (ao and st != "Active") or (pt and (ports in {"—", "None"} or pt not in ports)))

    def _visible_rows(self):
        return [{"ip": (self.table.item(r, 0).text() if self.table.item(r, 0) else ""),
                 "status": (self.table.item(r, 1).text() if self.table.item(r, 1) else ""),
                 "open_ports": (self.table.item(r, 2).text() if self.table.item(r, 2) else "")}
                for r in range(self.table.rowCount()) if not self.table.isRowHidden(r)]

    def _export_results(self, fmt):
        rows = self._visible_rows()
        if not rows: QMessageBox.information(self, UI_COPY["no_data"], UI_COPY["no_visible_rows"]); return
        path, _ = QFileDialog.getSaveFileName(self, "Export", f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{fmt}")
        if not path: return
        try:
            if fmt == "csv":
                with open(path, "w", newline="", encoding="utf-8") as fp:
                    w = csv.DictWriter(fp, fieldnames=["ip", "status", "open_ports"]); w.writeheader(); w.writerows(rows)
            else:
                with open(path, "w", encoding="utf-8") as fp: json.dump(rows, fp, indent=2)
            self.audit_event.emit(f"scan_export {fmt} {path}")
            self.status.setText(f"Exported {len(rows)} rows")
        except Exception as e: QMessageBox.warning(self, UI_COPY["export_failed"], str(e))

    def _compare_with_history(self):
        idx = self.history_combo.currentData()
        if idx is None: QMessageBox.information(self, UI_COPY["history"], UI_COPY["history_select"]); return
        if idx < 0 or idx >= len(self._history): return
        sel = self._history[idx]
        cur, prev = {r["ip"]: r for r in self._scan_rows}, {r["ip"]: r for r in sel["rows"]}
        added = [ip for ip in cur if ip not in prev]
        removed = [ip for ip in prev if ip not in cur]
        changed = [ip for ip in cur.keys() & prev.keys() if cur[ip].get("open_ports") != prev[ip].get("open_ports")]
        QMessageBox.information(self, UI_COPY["scan_comparison"],
            f"vs {sel['timestamp']}\nAdded: {len(added)}\nRemoved: {len(removed)}\nChanged: {len(changed)}")
        self.audit_event.emit(f"compare +{len(added)} -{len(removed)} ~{len(changed)}")

    def shutdown(self): self._cancel.set()


# ═══════════════════════════════════════════════════════════════════════════════
#  ChatPanel, ControlPanel, AuditLogPanel
# ═══════════════════════════════════════════════════════════════════════════════
class ChatPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ChatPanel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        hdr = QLabel(UI_COPY["messages"])
        hdr.setObjectName("SectionHeader")
        lay.addWidget(hdr)
        self.history = QTextEdit()
        self.history.setObjectName("ChatHistory"); self.history.setReadOnly(True)
        lay.addWidget(self.history, stretch=1)
        ir = QHBoxLayout()
        ir.setContentsMargins(12, 8, 12, 12); ir.setSpacing(8)
        self.input_field = QLineEdit()
        self.input_field.setObjectName("ChatInput")
        self.input_field.setPlaceholderText(UI_COPY["chat_placeholder"])
        ir.addWidget(self.input_field)
        self.send_btn = QPushButton(UI_COPY["send"])
        self.send_btn.setObjectName("BtnSend")
        self.send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_btn.setFixedWidth(64)
        self.send_btn.setIcon(_icon("message-circle"))
        ir.addWidget(self.send_btn)
        lay.addLayout(ir)

    def append_message(self, from_id: str, text: str):
        t = current_theme()
        ts = datetime.now().strftime("%H:%M:%S")
        cm = {"server": t.accent, "system": ACCENT_PURPLE}
        nc = cm.get(from_id, t.success)
        self.history.append(
            f'<div style="margin:4px 0;padding:8px 10px;border-radius:8px;'
            f'background:{t.bg_card};border:1px solid {t.border};">'
            f'<span style="color:{nc};font-weight:700;font-size:12px;">{from_id}</span> '
            f'<span style="color:{t.text_dim};font-size:10px;">{ts}</span>'
            f'<div style="color:{t.text_primary};font-size:12px;margin-top:3px;">{text}</div>'
            f'</div>')
        self.history.verticalScrollBar().setValue(self.history.verticalScrollBar().maximum())


class ControlPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ControlPanel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 0, 8, 12); lay.setSpacing(8)
        hdr = QLabel(UI_COPY["actions"])
        hdr.setObjectName("SectionHeader")
        lay.addWidget(hdr)
        self.btn_lock = QPushButton(UI_COPY["lock"])
        self.btn_lock.setObjectName("BtnLock")
        self.btn_lock.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_lock.setIcon(_icon("shield"))
        lay.addWidget(self.btn_lock)
        self.btn_shutdown = QPushButton(UI_COPY["shutdown"])
        self.btn_shutdown.setObjectName("BtnShutdown")
        self.btn_shutdown.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_shutdown.setIcon(_icon("power"))
        lay.addWidget(self.btn_shutdown)
        self.btn_restart = QPushButton(UI_COPY["restart"])
        self.btn_restart.setObjectName("BtnRestart")
        self.btn_restart.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_restart.setIcon(_icon("refresh-cw"))
        lay.addWidget(self.btn_restart)

    def set_enabled(self, enabled: bool):
        self.btn_lock.setEnabled(enabled)
        self.btn_shutdown.setEnabled(enabled)
        self.btn_restart.setEnabled(enabled)


class AuditLogPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AuditLogPanel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        hdr = QLabel(UI_COPY["audit_log"])
        hdr.setObjectName("SectionHeader")
        lay.addWidget(hdr)
        self.view = QTextEdit()
        self.view.setObjectName("AuditLogView")
        self.view.setReadOnly(True); self.view.setMinimumHeight(120)
        lay.addWidget(self.view)

    def append_event(self, category: str, message: str):
        t = current_theme()
        ts = _audit_ts()
        self.view.append(
            f"<span style='color:{t.text_dim};'>{ts}</span> "
            f"<span style='color:{t.info};font-weight:700'>[{category}]</span> "
            f"<span style='color:{t.text_primary};'>{message}</span>")
        self.view.verticalScrollBar().setValue(self.view.verticalScrollBar().maximum())


# ═══════════════════════════════════════════════════════════════════════════════
#  TabPanel — Right sidebar with underline tabs + icons
# ═══════════════════════════════════════════════════════════════════════════════
class TabPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("RightPanel")
        self.setMinimumWidth(290)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("RightTabs")
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(False)
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        self.tabs.setElideMode(Qt.TextElideMode.ElideRight)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        lay.addWidget(self.tabs, stretch=1)

        self.chat = ChatPanel()
        self.tabs.addTab(self._wrap(self.chat), _icon("message-circle"), UI_COPY.get("tab_chat", "Chat"))

        self.graph = NetworkGraph()
        self.controls = ControlPanel()
        ct = QWidget()
        cl = QVBoxLayout(ct)
        cl.setContentsMargins(0, 0, 0, 0); cl.setSpacing(6)
        cl.addWidget(self.graph)
        cl.addWidget(self.controls)
        cl.addStretch(1)
        self.tabs.addTab(self._wrap(ct), _icon("cpu"), UI_COPY.get("tab_controls", "Controls"))

        self.transfer = TransferPanel()
        self.tabs.addTab(self._wrap(self.transfer), _icon("upload"), UI_COPY.get("tab_transfer", "Transfer"))

        self.scanner = NetworkScannerPanel()
        self.tabs.addTab(self._wrap(self.scanner), _icon("search"), UI_COPY.get("tab_scanner", "Scanner"))

        self.audit = AuditLogPanel()
        self.tabs.addTab(self._wrap(self.audit), _icon("file-text"), UI_COPY.get("tab_audit", "Logs"))

    def _wrap(self, widget):
        widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(8, 8, 8, 8); bl.setSpacing(4)
        bl.addWidget(widget)
        scroll = QScrollArea()
        scroll.setObjectName("RightTabScroll")
        scroll.setWidgetResizable(True)
        scroll.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(body)
        return scroll

RightPanel = TabPanel


# ═══════════════════════════════════════════════════════════════════════════════
#  DashboardLayout — 3-zone with collapsible right + theme toggle
# ═══════════════════════════════════════════════════════════════════════════════
class DashboardLayout(QWidget):
    theme_toggled = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setHandleWidth(1)

        self.sidebar = ClientListPanel()
        self.sidebar.setFixedWidth(230)

        # Theme toggle at bottom of sidebar
        self._theme_btn = QPushButton()
        self._theme_btn.setObjectName("ThemeToggle")
        self._theme_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._theme_btn.setIcon(_icon("sun"))
        self._theme_btn.setText("Light Mode")
        self._theme_btn.clicked.connect(self.theme_toggled.emit)
        self.sidebar.layout().addWidget(self._theme_btn)

        self.splitter.addWidget(self.sidebar)

        self.viewer = ScreenViewer()
        self.splitter.addWidget(self.viewer)

        self.right_panel = TabPanel()
        self.right_panel.setMinimumWidth(290)
        self.splitter.addWidget(self.right_panel)

        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setCollapsible(0, False)
        self.splitter.setCollapsible(1, False)
        self.splitter.setCollapsible(2, True)
        self.splitter.setSizes([230, 860, 320])

        self._collapsed = False
        self._collapse_btn = QPushButton("◂")
        self._collapse_btn.setObjectName("CollapseToggle")
        self._collapse_btn.setToolTip("Toggle panel")
        self._collapse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._collapse_btn.clicked.connect(self._toggle_right)
        self._collapse_btn.setParent(self)
        self._collapse_btn.raise_()

        lay.addWidget(self.splitter, stretch=1)

    def update_theme_btn(self, theme: Theme):
        if theme.name == "dark":
            self._theme_btn.setIcon(_icon("sun"))
            self._theme_btn.setText("Light Mode")
        else:
            self._theme_btn.setIcon(_icon("moon"))
            self._theme_btn.setText("Dark Mode")

    def _toggle_right(self):
        self._collapsed = not self._collapsed
        if self._collapsed:
            self._saved = self.splitter.sizes()
            s = self.splitter.sizes(); s[2] = 0; self.splitter.setSizes(s)
            self._collapse_btn.setText("▸")
        else:
            self.splitter.setSizes(getattr(self, '_saved', [230, 860, 320]))
            self._collapse_btn.setText("◂")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._collapse_btn.move(self.width() - self._collapse_btn.width() - 8, 8)

DashboardBody = DashboardLayout


# ═══════════════════════════════════════════════════════════════════════════════
#  MainWindow
# ═══════════════════════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self, bridge: ServerBridge, host: str, port: int):
        super().__init__()
        global _current_theme
        self.bridge = bridge
        self._selected_client: Optional[str] = None
        self._current_fps = 0.0
        self._current_latency = 0.0
        self._latest_stats: Dict[str, dict] = {}

        self.setWindowTitle("Remote Desktop Manager")
        self.setMinimumSize(1100, 700)
        self.resize(1440, 880)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        self.top_bar = StatsBar(host, port)
        root.addWidget(self.top_bar)

        self.dashboard = DashboardLayout()
        self.sidebar = self.dashboard.sidebar
        self.viewer = self.dashboard.viewer
        self.right_panel = self.dashboard.right_panel
        root.addWidget(self.dashboard, stretch=1)

        # Theme toggle
        self.dashboard.theme_toggled.connect(self._toggle_theme)

        # Wire signals (all preserved)
        self.bridge.clients_changed.connect(self._on_clients_changed)
        self.bridge.frame_received.connect(self._on_frame)
        self.bridge.stats_updated.connect(self._on_stats)
        self.bridge.chat_received.connect(self._on_chat)
        self.bridge.client_disconnected.connect(self._on_client_disconnected)
        self.bridge.file_transfer_progress.connect(self._on_transfer_progress)
        self.bridge.file_transfer_done.connect(self._on_transfer_done)
        self.bridge.session_summary.connect(self._on_session_summary)
        self.bridge.transfer_queue_updated.connect(self._on_transfer_queue_updated)

        self.sidebar.client_list.currentItemChanged.connect(self._on_client_selected)
        self.right_panel.chat.send_btn.clicked.connect(self._on_send_chat)
        self.right_panel.chat.input_field.returnPressed.connect(self._on_send_chat)
        self.right_panel.controls.btn_lock.clicked.connect(lambda: self._send_command("LOCK"))
        self.right_panel.controls.btn_shutdown.clicked.connect(lambda: self._send_command("SHUTDOWN"))
        self.right_panel.controls.btn_restart.clicked.connect(lambda: self._send_command("RESTART"))
        self.viewer.files_dropped.connect(self._on_files_dropped)
        self.right_panel.transfer.files_selected.connect(self._on_files_dropped)
        self.right_panel.transfer.cancel_btn.clicked.connect(self._on_cancel_transfer)
        self.right_panel.transfer.retry_btn.clicked.connect(self._on_retry_transfer)
        self.right_panel.scanner.audit_event.connect(lambda msg: self._log_audit("SCAN", msg))

        self.right_panel.controls.set_enabled(False)
        self._apply_theme(_current_theme)
        self._log_audit("SYSTEM", "UI initialized")

    def _toggle_theme(self):
        global _current_theme
        _current_theme = LIGHT if _current_theme.name == "dark" else DARK
        self._apply_theme(_current_theme)

    def _apply_theme(self, theme: Theme):
        QApplication.instance().setStyleSheet(get_stylesheet(theme))
        self.centralWidget().setStyleSheet(f"background-color: {theme.bg_root};")
        self.dashboard.update_theme_btn(theme)

    def _on_clients_changed(self, client_ids):
        self.sidebar.update_clients(client_ids, self._selected_client)
        if self._selected_client and self._selected_client not in client_ids:
            self._selected_client = None
            self.viewer.clear_frame(); self.right_panel.graph.clear()
            self.right_panel.controls.set_enabled(False)

    def _on_client_selected(self, current, _prev):
        if current is None:
            self._selected_client = None
            self.viewer.clear_frame(); self.right_panel.graph.clear()
            self.right_panel.controls.set_enabled(False); return
        cid = current.data(Qt.ItemDataRole.UserRole)
        self._selected_client = cid
        self.bridge.select_client(cid)
        self.right_panel.controls.set_enabled(True)

    def _on_frame(self, client_id, img):
        if client_id == self._selected_client:
            self.viewer.show_frame(img)
            self.viewer.update_hud(client_id, self._current_fps, self._current_latency)

    def _on_stats(self, stats):
        self._latest_stats = dict(stats)
        self.top_bar.update_stats(stats, self._selected_client)
        self.sidebar.update_health(stats, self._selected_client)
        if self._selected_client and self._selected_client in stats:
            self._current_fps = stats[self._selected_client].get("fps", 0.0)
            self._current_latency = stats[self._selected_client].get("ping_ms", 0.0)
            self.viewer.update_hud(self._selected_client, self._current_fps, self._current_latency)
            self.right_panel.graph.add_point(self._current_latency)

    def _on_chat(self, from_id, _to, text):
        self.right_panel.chat.append_message(from_id, text)

    def _on_client_disconnected(self, client_id):
        self.right_panel.chat.append_message("system", f"⚠  {client_id} disconnected")

    def _on_transfer_progress(self, client_id, percent, label):
        if self._selected_client == client_id:
            self.right_panel.transfer.set_progress(percent, f"{percent:>3}% → {client_id}  |  {_format_transfer_label(label)}")

    def _on_transfer_done(self, ok, message):
        self.right_panel.chat.append_message("system", f"{'✅' if ok else '❌'}  {message}")
        self._log_audit("TRANSFER", message)
        self.right_panel.transfer.set_progress(100 if ok else 0, "Complete" if ok else "Failed")

    def _on_transfer_queue_updated(self, tasks):
        self.right_panel.transfer.update_queue(tasks)

    def _on_session_summary(self, summary):
        cid = summary.get("client_id", "?")
        dur = float(summary.get("duration_s", 0))
        tx = float(summary.get("bytes_sent", 0)) / 1048576
        rx = float(summary.get("bytes_recv", 0)) / 1048576
        self.right_panel.chat.append_message("system",
            f"Session: {cid} — {dur:.1f}s, TX {tx:.2f}MB, RX {rx:.2f}MB")
        self._log_audit("SYSTEM", f"session {cid} {dur:.1f}s")

    def _on_send_chat(self):
        text = self.right_panel.chat.input_field.text().strip()
        if not text: return
        self.bridge.send_chat(text, self._selected_client or "*")
        self.right_panel.chat.input_field.clear()

    def _on_files_dropped(self, file_paths):
        if not self._selected_client:
            QMessageBox.information(self, UI_COPY["no_client_selected"], UI_COPY["no_client_selected_msg"]); return
        clean = [str(p) for p in file_paths if isinstance(p, str) and p]
        if not clean: return
        added = self.bridge.enqueue_files(self._selected_client, clean)
        if added <= 0: self.right_panel.transfer.set_progress(0, "No files added"); return
        first = os.path.basename(clean[0])
        self.right_panel.transfer.set_progress(0, f"Queued {first}" + ("" if added == 1 else f" (+{added-1})"))
        self._log_audit("TRANSFER", f"queued {added} file(s) → {self._selected_client}")

    def _on_cancel_transfer(self):
        tid = self.right_panel.transfer.selected_task_id()
        if tid and self.bridge.cancel_transfer(tid): self._log_audit("TRANSFER", f"cancel {tid[:8]}")

    def _on_retry_transfer(self):
        tid = self.right_panel.transfer.selected_task_id()
        if tid and self.bridge.retry_transfer(tid): self._log_audit("TRANSFER", f"retry {tid[:8]}")

    def _log_audit(self, category, message):
        self.right_panel.audit.append_event(category, message)

    def _send_command(self, action):
        if not self._selected_client: return
        t = current_theme()
        if action not in {"LOCK", "SHUTDOWN"}:
            ok = self.bridge.send_command(self._selected_client, action)
            self.right_panel.chat.append_message("system",
                f"{'✅' if ok else '❌'}  {action} → {self._selected_client}")
            self._log_audit("COMMAND", f"{action} -> {self._selected_client}" if ok else f"FAILED {action}")
            return
        labels = {"LOCK": UI_COPY["lock"], "SHUTDOWN": UI_COPY["shutdown"], "RESTART": UI_COPY["restart"]}
        label = labels.get(action, action)
        reply = QMessageBox.question(self, f"Confirm {label}",
            f"<p style='font-size:13px;'>{label} <b>{self._selected_client}</b>?</p>"
            f"<p style='color:{t.text_muted};font-size:12px;'>Executes immediately.</p>",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes: return
        ok = self.bridge.send_command(self._selected_client, action)
        self.right_panel.chat.append_message("system",
            f"{'✅' if ok else '❌'}  {action} → {self._selected_client}")
        self._log_audit("COMMAND", f"{action} -> {self._selected_client}" if ok else f"FAILED {action}")

    def closeEvent(self, event):
        self.right_panel.scanner.shutdown()
        super().closeEvent(event)


# ═══════════════════════════════════════════════════════════════════════════════
#  Entry Point
# ═══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description="Remote Desktop Manager — GUI Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--password", default="lan-demo-123")
    args = parser.parse_args()

    server = RemoteManagerServer(args.host, args.port, args.password)
    server._screen_display_loop = lambda: None

    threading.Thread(target=server.start, daemon=True).start()

    app = QApplication(sys.argv)
    app.setStyleSheet(get_stylesheet(DARK))
    app.setWindowIcon(_icon("activity"))
    app.setFont(QFont("Inter", 13))

    bridge = ServerBridge(server)
    bridge.start()
    window = MainWindow(bridge, args.host, args.port)
    window.setWindowIcon(_icon("monitor"))
    window.show()

    exit_code = app.exec()
    bridge.stop()
    server.shutdown()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
