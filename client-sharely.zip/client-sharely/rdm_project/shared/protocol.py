from enum import Enum


class MessageType(str, Enum):
	CHAT = "chat"
	COMMAND = "command"
	SCREEN_FRAME = "screen_frame"
	FILE_META = "file_meta"
	FILE_CHUNK = "file_chunk"
	FILE_END = "file_end"
	PING = "ping"
	PONG = "pong"
	AUTH = "auth"
	STATUS = "status"


__all__ = ["MessageType"]
